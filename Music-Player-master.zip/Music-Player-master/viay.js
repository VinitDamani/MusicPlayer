var i=10 ; 
   do { 
       console.log("hii"); 
     } while(i<5);

     





