# Music-Player
Muisc Plyer using HTML , CSS and JavaScript.
